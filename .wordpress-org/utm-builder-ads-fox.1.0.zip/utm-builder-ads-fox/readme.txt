=== Adsfox.com  UTM Builder Adsfox ===
Contributors: Adsfox.com
Donate link:
Tags: UTM Builder, UTM Redirect, URL short
Requires at least: 5.6.4
Tested up to: 5.8.3
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The easy way to create short urls for redirect with UTM parameter.

== Description ==

Create a short Link for shering on different platforms. It will be redirected and attached your choosen UTM parameter

= Create your short link in just one minute =

1. Choose your Link
2. Attach the Parameter
3. Create your short URL for redirect

== Installation ==

= Using the WordPress Admin Console =
1. Go to the 'Plugins' section of your WordPress Admin Console, and click on 'Add New'.
2. Search for "UTM Builder Adsfox" and click 'Install Now' to install the plugin.
3. Activate the plugin and navigate to "UTM Adsfox" from the WP menu.


== Frequently Asked Questions ==

= How does the UTM Builder Adsfox work? =
Redirect from your Short URL to the choosen URL with UTM parameter.

https://yourSite.com/SpecialOffer  
to  
https://yourSite.com/productCategory/product/utm_source=youtube/utm_medium=influencer/campaign=influencr_name


= What data will be stored using the Link Facebook function? =
It will be stored in your Database the short and the URL with your parameters

= Is the tool free? =
UTM Builder Adsfox is free to use.
License URI: https://www.gnu.org/licenses/gpl-2.0.html

= What is Adsfox? =
Is an online advertising platform for creating successful, data-driven campaigns in just a few clicks.

= Where can I ask for support? =
If you have any questions, visit our website and use the contact form:
https://adsfox.com/contact

== Screenshots ==

1. UTM Parameter Setup with short URL
2. List of created URLs

== Changelog ==


